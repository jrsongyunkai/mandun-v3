// 项目设置
var ctxName = ''
var hostName = document.location.protocol + '//' + window.location.host
var ctxPaths = hostName + ctxName // 为空时为相对地址
var mapKey = 'vZGBPFRiVu94CE9SQjS5gTPH2Vy0PmWI'
// var cdnPaths = process.env.NODE_ENV !== 'production' ? 'v3cdn5.snd02.com' : ctxPaths
